--[[
Copyright © 2026 Broguypal

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
]]

-- CastStill - holds movement-interruptible actions until the client reports the
-- same position twice (two matching 0x015 packets), or until a short timeout
-- expires, whichever comes first. Nothing is synthesized, only delayed.

_addon.name     = 'CastStill'
_addon.author   = 'Broguypal'
_addon.version  = '1.3.0-dev'
_addon.commands = {'caststill'}

require('pack')
local res = require('resources')
local config = require('config')

local recent_window  = 1.25
local settings = config.load({mode = 'recent', hold = 0.35, firststop_hold = 5.0})
local firststop_settle = 0.20 -- fresh stationary interval; prevents a lone repeated packet from releasing
local bypass_window  = 1.50
local st_window      = 30.00
local probe_interval = 10.00
local probe_timeout  = 1.50
local auto_order     = true

local cs = {
    last_reported   = nil,
    last_move_time  = -999,
    is_settled      = true,
    client_last_pos = nil,
    client_move_time = -999,

    pending         = nil,
    pending_time    = 0,
    bypass_until    = 0,
    st_until        = 0,

    gs_present      = false,
    gs_probe_until  = nil,
    gs_probe_reload = false,
    gs_next_probe   = 0,
}

local function get_pos()
    local info = windower.ffxi.get_info()
    if not info or not info.logged_in or info.loading then return nil end
    local p = windower.ffxi.get_player()
    if not p or not p.index then return nil end
    local me = windower.ffxi.get_mob_by_index(p.index)
    if me and me.x and me.y then
        return { x = me.x, y = me.y }
    end
    return nil
end

local function same_pos(p1, p2)
    if not p1 or not p2 then return false end
    return p1.x == p2.x and p1.y == p2.y
end

local function recently_moving()
    return (os.clock() - cs.last_move_time) <= recent_window
end

local function server_knows_pos()
    if not cs.last_reported then return false end
    return same_pos(get_pos(), cs.last_reported)
end

local function should_gate()
    if os.clock() < cs.bypass_until then return false end
    if settings.mode == 'firststop' then
        local pos = get_pos()
        if pos and cs.last_reported and not same_pos(pos, cs.last_reported) then return true end
        if not cs.is_settled then return true end
        return recently_moving() or (os.clock() - cs.client_move_time < firststop_settle)
    end
    if not recently_moving() or cs.is_settled then return false end
    return true
end

-- Poll client position as well as outgoing reports: catches movement that
-- begins before the next 0x015 is sent. 0x015 remains our settle evidence.
local function track_client_movement()
    local pos = get_pos()
    if not pos then return end
    if cs.client_last_pos and not same_pos(pos, cs.client_last_pos) then
        cs.client_move_time = os.clock()
        cs.is_settled = false
    end
    cs.client_last_pos = pos
end

local function ready_to_release()
    if not cs.is_settled or not server_knows_pos() then return false end
    if settings.mode == 'firststop' then
        local last_move = math.max(cs.last_move_time, cs.client_move_time)
        return (os.clock() - last_move) >= firststop_settle
    end
    return true
end

local function token_for_id(id)
    local player = windower.ffxi.get_player()
    if player and player.id == id then
        return '<me>'
    end

    local t = windower.ffxi.get_mob_by_target('t')
    if t and t.id == id then
        return '<t>'
    end

    local mob = windower.ffxi.get_mob_by_id(id)
    if mob and not mob.is_npc and mob.name and mob.name ~= '' then
        return mob.name
    end

    return nil
end

local function command_from_packet(id, data)
    if id == 0x01A then
        local target   = data:unpack('I', 5)
        local category = data:unpack('H', 11)
        local param    = data:unpack('H', 13)

        local token = token_for_id(target)
        if not token then return nil end

        if category == 3 then
            local spell = res.spells[param]
            if not spell or not spell.name then return nil end
            return (spell.prefix or '/ma') .. ' "' .. spell.name .. '" ' .. token
        end

        if category == 16 then
            return '/ra ' .. token
        end

        return nil
    end

    if id == 0x037 then
        local target = data:unpack('I', 5)
        local slot   = data:unpack('C', 15)
        local bag    = data:unpack('C', 17)

        local token = token_for_id(target)
        if not token then return nil end

        local item = windower.ffxi.get_items(bag, slot)
        if not item or not item.id or item.id == 0 then return nil end

        local info = res.items[item.id]
        if not info or not info.name then return nil end

        return '/item "' .. info.name .. '" ' .. token
    end

    return nil
end

local function fire_pending()
    local p = cs.pending
    cs.pending = nil

    local info = windower.ffxi.get_info()
    if not info or not info.logged_in or info.loading then return end

    local cmd = p.cmd
    if cmd and cmd:lower():find('<t>', 1, true) then
        local t = windower.ffxi.get_mob_by_target('t')
        if not p.target or not t or t.id ~= p.target then
            -- Never fall back to replaying the raw packet for an old target.
            return
        end
    end

    cs.bypass_until = os.clock() + bypass_window

    if cmd then
        windower.send_command('input ' .. cmd)
    elseif p.data then
        windower.packets.inject_outgoing(p.id, p.data)
    end
end

local function track_position(data)
    local now = os.clock()
    local new_pos = { x = data:unpack('f', 5), y = data:unpack('f', 13) }

    if cs.last_reported then
        if same_pos(cs.last_reported, new_pos) then
            -- An unchanged 0x015 is a settle candidate; firststop mode
            -- additionally checks a fresh no-movement interval.
            cs.is_settled = true
        else
            cs.last_move_time = now
            cs.is_settled = false
        end
    end

    cs.last_reported = new_pos
end

local gated_text_prefixes = {
    ['/ma']           = true,
    ['/magic']        = true,
    ['/nin']          = true,
    ['/ninjutsu']     = true,
    ['/so']           = true,
    ['/song']         = true,
    ['/item']         = true,
    ['/ra']           = true,
    ['/range']        = true,
    ['/rangedattack'] = true,
    ['/throw']        = true,
    ['/shoot']        = true,
}

-- '' rather than true: a line blocked with true still reaches addons that don't
-- check the flag
windower.register_event('outgoing text', function(original, modified, blocked)
    if blocked == true then return end

    local line = modified
    if type(line) ~= 'string' or line:sub(1, 1) ~= '/' then return end

    local cmd = line:match('^(%S+)')
    if not cmd or not gated_text_prefixes[cmd:lower()] then return end

    if line:find('<st') then
        cs.st_until = os.clock() + st_window
        return
    end

    if os.clock() < cs.st_until then
        cs.st_until = 0
        return
    end

    -- these lines often carry a numeric target id. gearswap parses those, the
    -- client doesn't, so with no gearswap to replay to we gate the packet
    if not cs.gs_present then return end
    if not should_gate() then return end

    if cs.pending then
        return ''
    end

    local tid
    if line:lower():find('<t>', 1, true) then
        local target = windower.ffxi.get_mob_by_target('t')
        tid = target and target.id or nil
    end
    cs.pending = {cmd = line, target = tid}
    cs.pending_time = os.clock()
    return ''
end)

local function packet_is_gated(id, data)
    if id == 0x037 then return true end
    if id == 0x01A then
        local category = data:unpack('H', 11)
        return category == 3 or category == 16
    end
    return false
end

windower.register_event('outgoing chunk', function(id, original, modified, injected, blocked)
    if id == 0x015 then
        track_position(original)
        return
    end

    if blocked then return end
    if not packet_is_gated(id, modified) then return end

    if os.clock() < cs.bypass_until then
        cs.bypass_until = 0
        return
    end

    if not should_gate() then return end

    if cs.pending then
        return true
    end

    -- injected means precast already ran
    local cmd
    if not injected and cs.gs_present then
        cmd = command_from_packet(id, modified)
    end

    cs.pending = {
        cmd    = cmd,
        id     = id,
        data   = modified,
        target = modified:unpack('I', 5),
    }
    cs.pending_time = os.clock()
    return true
end)

-- polled, not one-shot: gearswap can come and go mid-session and it picks the
-- replay path. a bare 'gearswap' is a no-op for a loaded gearswap
windower.register_event('unhandled command', function(cmd)
    if cs.gs_probe_until and cmd and cmd:lower() == 'gearswap' then
        cs.gs_probe_until = nil
        cs.gs_probe_reload = false
        cs.gs_present = false
        return true
    end
end)

windower.register_event('prerender', function()
    track_client_movement()

    if cs.gs_probe_until then
        if os.clock() >= cs.gs_probe_until then
            cs.gs_probe_until = nil
            cs.gs_present = true
            -- windower dispatches in load order and gearswap eats the line, so
            -- it has to sit behind us
            if cs.gs_probe_reload then
                cs.gs_probe_reload = false
                windower.add_to_chat(8, 'CastStill: GearSwap is loaded, reloading it so CastStill intercepts first.')
                windower.send_command('lua reload gearswap')
            end
        end
    elseif os.clock() >= cs.gs_next_probe then
        local info = windower.ffxi.get_info()
        if info and not info.loading then
            cs.gs_next_probe  = os.clock() + probe_interval
            cs.gs_probe_until = os.clock() + probe_timeout
            windower.send_command('gearswap')
        end
    end

    if not cs.pending then return end

    if ready_to_release() then
        fire_pending()
        return
    end

    -- In firststop mode a timeout cancels, rather than firing a spell while
    -- the player is still running. In recent mode the original 0.35s
    -- fail-open behavior is preserved (unless the user adjusts hold).
    local timeout = settings.mode == 'firststop' and settings.firststop_hold or settings.hold
    if (os.clock() - cs.pending_time) >= timeout then
        if settings.mode == 'firststop' then
            cs.pending = nil
            windower.add_to_chat(207, '[CastStill] Pending action canceled: no stationary opening within '
                .. tostring(timeout) .. 's.')
        else
            fire_pending()
        end
    end
end)

windower.register_event('zone change', function()
    cs.pending        = nil
    cs.last_reported  = nil
    cs.last_move_time = -999
    cs.is_settled     = true
    cs.st_until       = 0
    cs.client_last_pos = nil
    cs.client_move_time = -999
end)

windower.register_event('load', function()
    windower.add_to_chat(8, 'CastStill v' .. _addon.version .. ' loaded.')
    cs.gs_probe_reload = auto_order
        and windower.file_exists(windower.addon_path .. '../GearSwap/GearSwap.lua')
    cs.gs_next_probe = os.clock() + 0.5
end)
local function show_status()
    windower.add_to_chat(207, '[CastStill] v' .. _addon.version
        .. ' | Mode: ' .. settings.mode
        .. ' | Recent hold: ' .. tostring(settings.hold) .. 's'
        .. ' | First-stop hold: ' .. tostring(settings.firststop_hold) .. 's'
        .. ' | Pending: ' .. (cs.pending and 'YES' or 'NO'))
end

local function show_help()
    windower.add_to_chat(207, '[CastStill] Commands:')
    windower.add_to_chat(207, '  //caststill mode recent|firststop - Original short gate or hold until first stop')
    windower.add_to_chat(207, '  //caststill hold <seconds>       - Set current mode max hold (0.1-15s)')
    windower.add_to_chat(207, '  //caststill status               - Show current settings')
    windower.add_to_chat(207, '  //caststill help                 - Show commands')
    windower.add_to_chat(207, '  //caststill restart              - Reload this addon')
    windower.add_to_chat(207, '  //caststill unload               - Unload this addon')
end

windower.register_event('addon command', function(cmd, arg)
    cmd = cmd and cmd:lower() or ''
    arg = arg and arg:lower() or nil
    if cmd == 'status' then show_status(); return end
    if cmd == 'help' or cmd == '' then show_help(); return end
    if cmd == 'restart' or cmd == 'unload' then
        windower.add_to_chat(207, '[CastStill] '.. (cmd == 'restart' and 'Reloading.' or 'Unloading.'))
        windower.send_command('lua ' .. (cmd == 'restart' and 'reload' or 'unload') .. ' caststill')
        return
    end
    if cmd == 'mode' then
        if arg ~= 'recent' and arg ~= 'firststop' then show_help(); return end
        settings.mode = arg
    elseif cmd == 'hold' then
        local seconds = tonumber(arg)
        if not seconds or seconds < 0.1 or seconds > 15 then show_help(); return end
        if settings.mode == 'firststop' then
            settings.firststop_hold = seconds
        else
            settings.hold = seconds
        end
    else
        show_help()
        return
    end
    -- A mode change must not retroactively reinterpret a queued packet.
    cs.pending = nil
    settings:save('all')
    show_status()
end)
